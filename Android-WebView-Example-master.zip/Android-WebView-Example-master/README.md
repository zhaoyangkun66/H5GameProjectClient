# Android-WebView-Example
This project shows you how to use Android's native webview wrapper to load site url
How to add and dismiss progressBar
And how to utilize the Swipe to refresh feature of Android's webView 
