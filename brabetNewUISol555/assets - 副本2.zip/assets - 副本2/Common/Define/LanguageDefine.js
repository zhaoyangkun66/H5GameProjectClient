let n ={} 
Object.defineProperty(n, "__esModule", {
    value: true
});
var o = function() {
    function e() {}
    return e.enus = "en-us",
    e.hiin = "hi-in",
    e.thth = "th-th",
    e.zhcn = "zh-cn",
    e.zhhk = "zh-hk",
    e.vivn = "vi-vn",
    e.idid = "id-id",
    e.intelugu = "in-telugu",
    e.inmarathi = "in-marathi",
    e.ptpt = "pt-pt",
    e.eses = "es_co",
    e
}();
n.default = o,
module.exports = n
