let n = {}

Object.defineProperty(n, "__esModule", {
    value: true
}),
    n.FormDefine = undefined,
    function (e) {
        e.Form = "Form",
            e.NewSysMsg = "NewSysMsg",
            e.SceneInfo = "SceneInfo",
            e.Sound = "Sound",
            e.RoomModeInfo = "RoomModeInfo",
            e.Effect = "Effect"
    }(n.FormDefine || (n.FormDefine = {}))

module.exports = n
