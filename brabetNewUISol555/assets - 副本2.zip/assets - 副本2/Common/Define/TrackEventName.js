let n ={} 

Object.defineProperty(n, "__esModule", {
    value: true
});
var o = function() {
    function e() {}
    return e.LAUNCH_START_BEGIN = "launch_start_begin",
    e.LAUNCH_START_END = "launch_start_end",
    e.LAUNCH_GAME_CONFIG_BEGIN = "launch_game_config_begin",
    e.LAUNCH_GAME_CONFIG_END = "launch_game_config_end",
    e.LAUNCH_LOAD_RES_BEGIN = "launch_load_res_begin",
    e.LAUNCH_LOAD_RES_END = "launch_load_res_end",
    e.VISITOR_LOGIN_BEGIN = "visitor_login_begin",
    e.VISITOR_LOGIN_END = "visitor_login_end",
    e.EXERCISE_LOGIN_BEGIN = "exercise_login_begin",
    e.EXERCISE_LOGIN_END = "exercise_login_end",
    e.TOKEN_LOGIN_BEGIN = "token_login_begin",
    e.TOKEN_LOGIN_END = "token_login_end",
    e.THIRD_LOGIN_BEGIN = "third_login_begin",
    e.THIRD_LOGIN_END = "third_login_end",
    e.LOGIN_GS_BEGIN = "login_gs_begin",
    e.LOGIN_GS_CONNECTED = "login_gs_connected",
    e.LOGIN_GS_END = "login_gs_end",
    e.CLICK_BTN_FB = "click_btn_fb",
    e.CLICK_BTN_LOGIN = "click_btn_login",
    e.USER_LOGIN_BEGIN = "user_login_begin",
    e.USER_LOGIN_END = "user_login_end",
    e.CLICK_BTN_REGISTER = "click_btn_register",
    e.USER_REGISTER_BEGIN = "user_register_begin",
    e.USER_REGISTER = "register",
    e.USER_REGISTER_END = "user_register_end",
    e.ENTER_HALL_SCENE = "enter_hall_scene",
    e.CLICK_ENTER_GAME = "click_enter_game",
    e.ENTER_GAME = "enter_game",
    e.GET_USER_INFO = "get_user_info",
    e.GET_USER_SIGN = "get_user_sign",
    e.GET_WAY_SELECT = "get_way_select",
    e.SIGN_LOAD_SUCCESS = "sign_load_success",
    e.OPEN_RECHARGE = "openrecharge",
    e.RECHARGE = "recharge",
    e.AJ_CONSUMEEVENT = "AJ_CONSUMEEVENT",
    e.PAGETRACK_EVENT_RECHARGE_ENTER = "PAGETRACK_EVENT_RECHARGE_ENTER",
    e.PAGETRACK_EVENT_RECHARGE_SWITCHTAB = "PAGETRACK_EVENT_RECHARGE_SWITCHTAB",
    e.PAGETRACK_EVENT_RECHARGE_GAME = "PAGETRACK_EVENT_RECHARGE_GAMEENTER",
    e.PAGETRACK_EVENT_RECHARGE_VIP = "PAGETRACK_EVENT_RECHARGE_VIPENTER",
    e.PAGETRACK_EVENT_RECHARGE_ACTIVITY = "PAGETRACK_EVENT_RECHARGE_ACTIVITY",
    e.PAGETRACK_EVENT_RECHARGE_RELEGATION = "PAGETRACK_EVENT_RECHARGE_RELEGATION",
    e.PAGETRACK_EVENT_USERCENTER_TOPENTER = "PAGETRACK_EVENT_USERCENTER_TOPENTER",
    e.PAGETRACK_EVENT_USERCENTER_WITHDRAW = "PAGETRACK_EVENT_USERCENTER_WITHDRAW",
    e.PAGETRACK_EVENT_USERCENTER_BOTTOM = "PAGETRACK_EVENT_USERCENTER_BOTTOM",
    e.PAGETRACK_EVENT_WITHDRAW_USERCENTER = "PAGETRACK_EVENT_WITHDRAW_USERCENTER",
    e.PAGETRACK_EVENT_WITHDRAW_SWITCHTAB = "PAGETRACK_EVENT_WITHDRAW_SWITCHTAB",
    e.PAGETRACK_EVENT_WITHDRAW_SHARE = "PAGETRACK_EVENT_WITHDRAW_SHARE",
    e.PAGETRACK_EVENT_WITHDRAW_ACTIVITY = "PAGETRACK_EVENT_WITHDRAW_ACTIVITY",
    e
}();
n.default = o

module.exports = n
