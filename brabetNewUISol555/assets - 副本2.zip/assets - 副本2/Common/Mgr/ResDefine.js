let n ={} 
Object.defineProperty(n, "__esModule", {
    value: true
}),
n.PrefabRes = n.TextureRes = undefined,
n.TextureRes = {
    POKER_PATH: "common/atlas/poker",
    RUMMY_POKER_PATH: "common/atlas/RummyPoker",
    BIG_POKER_PATH: "common/atlas/poker_big"
},
n.PrefabRes = {},
module.exports = n
