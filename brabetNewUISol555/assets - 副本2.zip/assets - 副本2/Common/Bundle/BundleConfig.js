let n ={} 

Object.defineProperty(n, "__esModule", {
    value: true
}),
n.BundleNames = n.Config = undefined,
function(e) {
    e.assetBundle = {},
    e.isSkipCheckUpdate = false,
    e.TEST_HOT_UPDATE_URL_ROOT = "http://192.168.1.210/hotupdate",
    e.BUNDLE_HALL = "hall"
}(n.Config || (n.Config = {})),
n.BundleNames = {
    TP: "zhajinhua",
    RUMMY: "Game210",
    BCBM: "car",
    LHD: "DragonTiger",
    HHDZ: "honghei",
    SHZ: "shuihuzhuan",
    LUDO: "ludo",
    Game30: "Game30",
    TIENLEN: "tienlen",
    toubao: "toubao",
    LUNPAN: "lunpan",
    SLOT777: "777slot",
    SLOT2_777: "777_slot2",
    BAODIAN: "baodian",
    CRASH2: "crash2",
    SHIJIEBEI: "shijiebei",
    LROLLER: "LuckyRoller",
    Roulette: "Roulette",
    ABgame: "ABgame",
    Baccarat: "Baccarat",
    MINES: "MINES",
    AB_Classis: "ABjingdian",
    Dice: "Dice",
    Game620: "Game620",
    Game650: "Game650",
    Game700: "Game700",
    Game730: "Game730",
    Game750: "Game750",
    Game840: "Game840",
    Game850: "Game850",
    Game860: "Game860",
    Game890: "Game890",
    Game900: "Game900",
    Game910: "Game910",
    Game920: "Game920",
    Game970: "Game970",
    Game1050: "Game1050",
    Game1051: "Game1051",
    Game1052: "Game1052",
    Game1053: "Game1053",
    Game1054: "Game1054"
}

module.exports = n
