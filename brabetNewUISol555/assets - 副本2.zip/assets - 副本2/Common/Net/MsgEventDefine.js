let n ={} 

Object.defineProperty(n, "__esModule", {
    value: true
});
var o = function() {
    function e() {}
    return e.EVENT_JOIN_ROOM = "resp_join_room",
    e.EVENT_CREATE_ROOM = "resp_create_room",
    e.EVENT_ROOM_INFO = "resp_room_info",
    e.EVENT_LEAVE_ROOM = "resp_leave_room",
    e.EVENT_START = "resp_start",
    e.EVENT_READY = "resp_ready",
    e.EVENT_ROUND_READY = "resp_round_ready",
    e.EVENT_VOTE_DISSOVLE_ROOM = "resp_vote_dissolve_room",
    e.EVENT_DISSOVLE_ROOM = "resp_dissolve_room",
    e.EVENT_ONLINE_STATE = "resp_online_state",
    e.EVENT_ROOM_START_GAME = "resp_room_start_game",
    e.EVENT_ROOM_OPERATION = "resp_room_operation",
    e.EVENT_CHOOSE_SEAT = "resp_choose_seat",
    e.EVENT_SET_CASH = "resp_set_cash",
    e.EVENT_DELAY = "resp_delay",
    e.EVENT_SHUFFLE = "resp_shuffle",
    e.EVENT_REMATCH = "resp_rematch",
    e.EVENT_ROOM_END_GAME = "resp_room_end_game",
    e.EVENT_GAME_MESSAGE = "resp_game_message",
    e.EVENT_ROOM_RECYCLE = "resp_room_recycle",
    e.EVENT_MATCH_COUNTDOWN = "resp_match_countdown",
    e.EVENT_ROOM_CHAT = "resp_room_chat",
    e.EVENT_ROOM_FACE = "resp_room_face",
    e.EVENT_FACE = "resp_face",
    e.EVENT_BIG_WINNER_POOL = "resp_big_winner_pool",
    e.EVENT_SELF_JOIN_ROOM = "resp_self_join_room",
    e.EVENT_LOGIN = "resp_login",
    e.EVENT_LOGIN_FINISH = "resp_login_finish",
    e.EVENT_LOGOUT = "resp_logout",
    e.EVENT_NOTIFY = "resp_notify",
    e.EVENT_DISCONNECT = "disconnect",
    e.RSP_HALL_INFO = "RspHallInfo",
    e.HALL_END_ROUND = "HallEndRound",
    e.HALL_NOTIFY = "HallNotify",
    e
}();
n.default = o

module.exports = n
