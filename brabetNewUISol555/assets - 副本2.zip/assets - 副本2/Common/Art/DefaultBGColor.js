let n ={} 
Object.defineProperty(n, "__esModule", {
    value: true
}),
n.DefaultBGColor = undefined,
function(e) {
    e.Launch = "#0d131c",
    e.HallTop = "#161f2c"
}(n.DefaultBGColor || (n.DefaultBGColor = {})),
module.exports = n
