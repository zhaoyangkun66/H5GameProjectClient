var n = new Map;
n.set(30001, function () {
    return app.i18n.t("SC_RoomGame_GameAlready")
}),
    n.set(30101, function () {
        return app.i18n.t("SC_RoomGame_Assignmentfailed")
    }),
    n.set(30102, function () {
        return app.i18n.t("SC_RoomGame_Roomisfull")
    }),
    n.set(30103, function () {
        return app.i18n.t("SC_RoomGame_hadentered")
    }),
    n.set(30104, function () {
        return app.i18n.t("SC_RoomGame_passwordiswrong")
    }),
    n.set(30105, function () {
        return app.i18n.t("SC_RoomGame_RoomnotExist")
    }),
    n.set(30106, function () {
        return app.i18n.t("SC_RoomGame_CannotLeaveRoom")
    }),
    n.set(30107, function () {
        return app.i18n.t("SC_RoomGame_TheSeat")
    }),
    n.set(30108, function () {
        return app.i18n.t("SC_RoomGame_RoomMDoNotExist")
    }),
    n.set(30109, function () {
        return app.i18n.t("SC_RoomGame_NotTheOwner")
    }),
    n.set(30110, function () {
        return app.i18n.t("SC_RoomGame_Notintheroom")
    }),
    n.set(30111, function () {
        return app.i18n.t("SC_RoomGame_AccountFailed")
    }),
    n.set(30112, function () {
        return app.i18n.t("SC_RoomGame_RoomCardLack")
    }),
    n.set(30113, function () {
        return app.i18n.t("SC_RoomGame_ServerCheckFailed")
    }),
    n.set(30114, function () {
        return app.i18n.t("SC_RoomGame_NotinTheLine")
    }),
    n.set(30115, function () {
        return app.i18n.t("SC_RoomGame_LineIDError")
    }),
    n.set(30116, function () {
        return app.i18n.t("SC_RoomGame_WasntReady")
    }),
    n.set(30117, function () {
        return app.i18n.t("SC_RoomGame_RoomWrongState")
    }),
    n.set(30118, function () {
        return "BANCOUNTError"
    }),
    n.set(30119, function () {
        return "PAYTYPEError"
    }),
    n.set(30120, function () {
        return app.i18n.t("SC_RoomGame_DestroyRoomLimit")
    }),
    n.set(30121, function () {
        return app.i18n.t("SC_RoomGame_RoomGameStart")
    }),
    n.set(30122, function () {
        return "Not enough gold"
    }),
    n.set(30123, function () {
        return ""
    }),
    n.set(30124, function () {
        return ""
    }),
    n.set(30125, function () {
        return "line The service is not available"
    }),
    n.set(30126, function () {
        return app.i18n.t("SC_RoomGame_RoomGameStart")
    }),
    n.set(30900, function () {
        return app.i18n.t("UI.System_7")
    }),
    n.set(10004, function () {
        return app.i18n.t("SC_RoomGame_ServerFull")
    }),
    n.set(32113, function () {
        return app.i18n.t("SC_RoomGame_YouInRoomOrGame")
    }),
    n.set(30999, function () {
        return app.i18n.t("UI.System_7")
    }),
    n.set(50001, function () {
        return "Room status error"
    }),
    n.set(50008, function () {
        return "Not enough gold"
    }),
    module.exports = n


