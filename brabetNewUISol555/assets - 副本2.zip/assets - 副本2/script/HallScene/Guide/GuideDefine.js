let n ={} 
Object.defineProperty(n, "__esModule", {
    value: true
}),
n.GuideTypeByNum = n.Guide_Type = undefined,
(n.Guide_Type || (n.Guide_Type = {})).Guide_withdraw = "Guide_withdraw",
n.GuideTypeByNum = {
    Guide_withdraw: 1
},
module.exports = n
