let n ={} 

Object.defineProperty(n, "__esModule", {
    value: true
});
var o = function() {
    function e() {}
    return e.ENTER_GAME = "ENTER_GAME",
    e.ENTER_GAME_COMMON = "ENTER_GAME_COMMON",
    e.HOTUPDATE_DOWNLOAD = "HOTUPDATE_DOWNLOAD",
    e.DOWNLOAD_PROGRESS = "DOWNLOAD_PROGRESS",
    e
}();
n.default = o

module.exports = n
