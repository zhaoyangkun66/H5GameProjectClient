let n ={} 
Object.defineProperty(n, "__esModule", {
    value: true
}),
n.VIP_Num_Color = n.VIP_LineLbl_Color = n.VIP_Lbl_Color = undefined;
var o = function() {
    function e() {}
    return e.Color_Red = new cc.Color(255,0,0),
    e.Color_Green = new cc.Color(0,255,0),
    e.Color_White = new cc.Color(255,255,255),
    e.Color_Black = new cc.Color(0,0,0),
    e.Color_Gray = new cc.Color(125,125,125),
    e.Color_Purple = new cc.Color(255,125,255),
    e.Color_Orange = new cc.Color(255,125,0),
    e.Color_RoseRed = new cc.Color(253,62,208),
    e.Color_Blue = new cc.Color(72,211,242),
    e.Color_Yellow = new cc.Color(255,235,84),
    e.Color_LiteOrange = new cc.Color(255,165,102),
    e.Color_Brown = new cc.Color(89,38,3),
    e
}();
n.default = o,
n.VIP_Lbl_Color = ["#6C3C02", "#322E5C", "#6C3C02", "#185860", "#5baeff", "#311355", "#5f0065", "#6F0B19", "#7C2E0A", "#017069", "#44005E"],
n.VIP_LineLbl_Color = ["#CF9383", "#b1a5ce", "#FBE78B", "#63bcda", "#5a81e1", "#bd89fd", "#fc83df", "#e86665", "#e79d69", "#81dad9", "#b985d9"],
n.VIP_Num_Color = ["#FFC278", "#E0D4FF", "#FCFFD4", "#D4FDFF", "#D4E3FF", "#F8D4FF", "#FFD4FA", "#FFBABA", "#FFD6BA", "#BAF7FF", "#F7BAFF"],
module.exports = n
