let n ={} 
Object.defineProperty(n, "__esModule", {
    value: true
}),
n.MsgIDDefine = undefined;
var o = function() {
    function e() {}
    return e.Code_500 = "Code_500",
    e.System_44 = "UI.System_44",
    e.System_42 = "UI.System_42",
    e
}();
n.MsgIDDefine = o,
module.exports = n
