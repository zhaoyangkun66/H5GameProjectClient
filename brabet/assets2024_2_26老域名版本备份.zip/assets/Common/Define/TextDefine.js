let n ={} 
Object.defineProperty(n, "__esModule", {
    value: true
}),
n.TextDefine = undefined;
var o = function() {
    function e() {}
    return e.limit = "game_point_limit_text",
    e.withdraw = "currency_rate_withdraw_desc",
    e.usdt_withdraw = "usdt_withdraw_lang_desc",
    e.user_center_withdraw = "user_center_withdraw_desc",
    e.draw_amount = "draw_amount_withdraw_desc",
    e.player_welcome = "player_welcome_text",
    e.agent_welcome = "agent_welcome_text",
    e.customer_servic = "customer_servic_text",
    e.withdraw_add_text = "withdraw_add_text",
    e.withdraw_please_mask = "withdraw_please_mask_text",
    e.footer_notice_text = "footer_notice_text",
    e.web_cfg_title = "web_cfg_title",
    e
}();
n.TextDefine = o,
module.exports = n
