let n ={} 
Object.defineProperty(n, "__esModule", {
    value: true
});
var o = function() {
    function e() {}
    return e.EffectPosType_1 = 1,
    e.EffectPosType_2 = 2,
    e.EffectPosType_3 = 3,
    e.EffectPosType_4 = 4,
    e.EffectPosType_5 = 5,
    e.EffectPosType_6 = 6,
    e.EffectPosType_7 = 7,
    e.EffectPosType_8 = 8,
    e.EffectPosType_9 = 9,
    e.EffectPosType_10 = 10,
    e
}();
n.default = o,
module.exports = n
