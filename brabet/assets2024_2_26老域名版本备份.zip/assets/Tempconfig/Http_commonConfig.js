module.exports = {
    "kfoc_faq_logo": "",
    "down_urls": {
        "android_download_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/apk\/brabet1103.apk",
        "ios_download_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/index\/iosDownPage?down_url=&emb_url=\/uploads\/mobileconfig\/embedded10.mobileprovision"
    },
    "is_force": 0,
    "is_up": 2,
    "game_rows": 2,
    "gs_host": "gss.brabet.com",
    "gs_port": "28965",
    "gs_sport": "28966",
    "tx_record_url": "https:\/\/home.brabet.com\/gold\/tx_record",
    "web_url": "http:\/\/home.brabet.com",
    "withdraw_desc": "<div ><size=28><color=#ffffff>Once I submit a withdrawal request, how long will it take for my money to be transferred to my bank account?<\/size><\/color><br\/><br\/><span color: inherit;>1. Ensure that your KYC is complete.<\/span><br\/><span color: inherit;>2. Online transfers are processed on all days, except 2nd and 4th Saturdays, Sunday and RBI holidays.The withdrawal amount will be credited to your account within 1-3 working days of placing the withdrawal request.<\/span><br\/><span color: inherit;>3. You will need to furnish your Bank Account Numbe IFSC code of your Bank Branch and Bank Account holder Name for us to process your withdrawal using the online transfer facility. You only need to provide the required details once. The information will be auto-filled for future withdrawals.<\/span><br\/><br\/><size=28><color=#ffffff>Cashing rule<\/size><\/color><br\/><br\/><span color: inherit;>1. The gold won is credited to the amount that can be realized.<\/span><br\/><span color: inherit;>2.The portion of a gold coin held to produce a weight  <\/span><span color: inherit;>may be cashed.<\/span><br\/><span color: inherit;>3.Non-deliverable amount originally non-deliverable amount bet\/ BET multiple.<\/span><br\/><br\/>",
    "pay_instruction": {
        "status": "1",
        "desc": "Important instruction:For upi Payment:select paytm wallet then enter UPI and makepayment"
    },
    "stop_server_prompt": "Desculpe que estamos actualizando nosso sistema agora. por favor, tente de novo mais tarde.",
    "bind_tel_send_gold": "0",
    "app_bind_model": 1,
    "is_open_browser": 1,
    "notice_popup": 1,
    "notice_default": 2,
    "sign_popup": 0,
    "qrcode_open": false,
    "hu_url": "",
    "ios_download_url": "",
    "game_url": "",
    "android_download_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/apk\/brabet1103.apk",
    "user_agreement": "https:\/\/home.brabet.com\/index\/article\/gp\/userAgreement.html?pid=1",
    "privacy": "https:\/\/home.brabet.com\/index\/article\/gp\/privacy.html?pid=1",
    "show_arr": [],
    "aj_event_config": [
        {
            "type": "register",
            "key": ""
        },
        {
            "type": "recharge",
            "key": "",
            "currency": ""
        },
        {
            "type": "withdraw",
            "key": "",
            "currency": ""
        },
        {
            "type": "install",
            "key": "",
            "currency": ""
        },
        {
            "type": "openrecharge",
            "key": "",
            "currency": ""
        },
        {
            "type": "clickrecharge",
            "key": "",
            "currency": ""
        },
        {
            "type": "gotoPay",
            "key": "",
            "currency": ""
        },
        {
            "type": "common1",
            "key": "",
            "currency": ""
        },
        {
            "type": "common2",
            "key": "",
            "currency": ""
        },
        {
            "type": "reg_official",
            "key": ""
        },
        {
            "type": "user_keep",
            "key": ""
        },
        {
            "type": "first_recharge",
            "key": "",
            "currency": ""
        }
    ],
    "fb_event_config": [
        {
            "type": "register",
            "key": ""
        },
        {
            "type": "recharge",
            "key": "",
            "currency": ""
        },
        {
            "type": "withdraw",
            "key": "",
            "currency": ""
        },
        {
            "type": "install",
            "key": "",
            "currency": ""
        },
        {
            "type": "common1",
            "key": "",
            "currency": ""
        },
        {
            "type": "common2",
            "key": "",
            "currency": ""
        },
        {
            "type": "first_recharge",
            "key": "",
            "currency": ""
        }
    ],
    "more_items": "",
    "kefu_type": "1",
    "currency_show": "1",
    "currency_symbol": "R$",
    "hot_update_url": "https:\/\/home.brabet.com\/zip\/1_1\/",
    "pay_userinfo_fields": {
        "pay": {
            "name": 0,
            "phone": 0,
            "email": 0,
            "upi": 0,
            "taxid": "1",
            "zipcode": 0,
            "rfc": 0
        },
        "prepay": {
            "account": 0,
            "name": 0,
            "bank_id": 0,
            "bank": 0,
            "branch_bank": 0,
            "ifsc_code": 0,
            "bank_code": 0,
            "upi": 0,
            "repay_rfc": 0,
            "tel": "1",
            "email": "1",
            "taxid": "1",
            "pix_type": "1",
            "pix_key": "1",
            "account_type": 0,
            "account_digit": 0,
            "card_type": 0,
            "prepay_type": 0,
            "province": 0,
            "city": 0,
            "gcash_number": 0,
            "pay_maya_account": 0,
            "bank_card_type": 0,
            "gcash_type": 0,
            "pay_maya_type": 0,
            "repay_curp": 0,
            "repay_card_debit": 0,
            "repay_card_phone": 0,
            "repay_card_clabe": 0,
            "document_type": 0
        },
        "weight": {
            "account": "0",
            "name": "0",
            "bank": "0",
            "branch_bank": "0",
            "ifsc_code": "0",
            "upi": "0",
            "tel": "99",
            "email": "0",
            "taxid": "96",
            "pix_type": "98",
            "pix_key": "97",
            "account_type": "0",
            "account_digit": "0",
            "card_type": "0",
            "prepay_type": "0",
            "province": "0",
            "city": "0",
            "gcash_number": "0",
            "pay_maya_account": "0",
            "bank_card_type": "0",
            "gcash_type": "0",
            "pay_maya_type": "0"
        },
        "cpf_tips": ""
    },
    "share_app": [
        "1",
        "2"
    ],
    "version_position": "5",
    "stay_login_page": "0",
    "facebook_register_award": 0,
    "show_kyc_conf": 0,
    "ext_game_recharge_limit": {
        "220": 0,
        "250": 0,
        "260": 0,
        "270": 0,
        "280": 0,
        "290": 0,
        "310": 0,
        "320": 0,
        "340": 0,
        "350": 0,
        "400": 0,
        "410": 0,
        "440": 0,
        "500": 0
    },
    "direct_game": 0,
    "experience_recharge_limit": 0,
    "reg_login_weight_conf": [
        {
            "key": "email",
            "status": 1,
            "weight": "100"
        },
        {
            "key": "mobile",
            "status": 1,
            "weight": "90"
        }
    ],
    "bd_bet_count": 2,
    "game_arr": [],
    "notice_countdown_time": 2,
    "auto_clean_bet_switch": 0,
    "experience_conf": {
        "experience_server_show": 0,
        "is_experience_server": 0,
        "experience_server_text": "TESTE GRATUITO",
        "experience_server_url": "api.brabetonline.com"
    },
    "new_user_pop_ups": "0",
    "login_fail_limit": "0",
    "verification_code_status": "0",
    "bet_pop_up_config": "1,10,100,200,500,1000",
    "gc_url": "https:\/\/www.brabet.com\/license\/gc\/",
    "gs_host1": "gogs.brabet.com",
    "gs_port1": "",
    "gs_sport1": "8976",
    "ngs_switch": 0,
    "ranking_show_status": 1,
    "user_vip_lv_keep_switch": 1,
    "customer_logo_name": "BRABET",
    "ship_address_config": {
        "770": "https:\/\/luckyairships.net\/",
        "780": "https:\/\/luckyairships.net\/",
        "790": "https:\/\/luckyairships.net\/",
        "800": "https:\/\/luckyairships.net\/"
    },
    "recharge_default": "100",
    "game_partners": {
        "1": [
            {
                "name": "18 anos de idade",
                "img_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/uploads\/game_partners\/20230131\/da831a5767b44c90e94113494e39d8d5.png",
                "is_jump": 0,
                "jump_url": ""
            },
            {
                "name": "YouTube",
                "img_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/uploads\/game_partners\/20230131\/b96894718f6d5c6a0550e90d58412710.png",
                "is_jump": 0,
                "jump_url": ""
            },
            {
                "name": "Twitter",
                "img_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/uploads\/game_partners\/20230131\/6e942d0020161977f09decb100fbdae4.png",
                "is_jump": 0,
                "jump_url": ""
            },
            {
                "name": "tik tok",
                "img_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/uploads\/game_partners\/20230131\/7434f0f1fcaee5b2abcf30df2bd31d13.png",
                "is_jump": 0,
                "jump_url": ""
            },
            {
                "name": "FB",
                "img_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/uploads\/game_partners\/20230131\/02e381d4b0a7d972fae4667d1cadc21c.png",
                "is_jump": 0,
                "jump_url": ""
            },
            {
                "name": "Câmera",
                "img_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/uploads\/game_partners\/20230131\/1f83d3a30c5f9c1f981f0c1a613c15b5.png",
                "is_jump": 0,
                "jump_url": ""
            },
            {
                "name": "Telefone",
                "img_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/uploads\/game_partners\/20230131\/49fd091205a41f24b867838ae142d7c1.png",
                "is_jump": 0,
                "jump_url": ""
            }
        ],
        "2": [
            {
                "name": "Google",
                "img_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_partners\/2.png",
                "is_jump": 0,
                "jump_url": ""
            },
            {
                "name": "PGGame",
                "img_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_partners\/3.png",
                "is_jump": 0,
                "jump_url": ""
            },
            {
                "name": "CQ9",
                "img_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_partners\/6.png",
                "is_jump": 0,
                "jump_url": ""
            },
            {
                "name": "facebook",
                "img_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/uploads\/game_partners\/20230201\/245a625b51524e4e35fe59b4cf47e1bb.png",
                "is_jump": 0,
                "jump_url": ""
            },
            {
                "name": "JJGAME",
                "img_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/uploads\/game_partners\/20230203\/c1aea45d1ec7c399687aabf732026bed.png",
                "is_jump": 0,
                "jump_url": ""
            },
            {
                "name": "EVO",
                "img_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_partners\/5.png",
                "is_jump": 0,
                "jump_url": ""
            },
            {
                "name": "EVOPLAY",
                "img_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_partners\/4.png",
                "is_jump": 0,
                "jump_url": ""
            },
            {
                "name": "PG",
                "img_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_partners\/9.png",
                "is_jump": 0,
                "jump_url": ""
            },
            {
                "name": "CP GMAES",
                "img_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/uploads\/game_partners\/20230901\/8939521352aa9a01ba6e5b6a4b56f078.png",
                "is_jump": 0,
                "jump_url": ""
            },
            {
                "name": "TADA",
                "img_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/uploads\/game_partners\/20230901\/ae04634167b69f62059ee5118fd4a865.png",
                "is_jump": 0,
                "jump_url": ""
            },
            {
                "name": "JDB",
                "img_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/uploads\/game_partners\/20230901\/8f088f5ce1415ae8dfe56950e1048f34.png",
                "is_jump": 0,
                "jump_url": ""
            },
            {
                "name": "YESBINGO",
                "img_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/uploads\/game_partners\/20230901\/a81af8a67fc7ffbf4e254818cfc25980.png",
                "is_jump": 0,
                "jump_url": ""
            }
        ],
        "3": [
            {
                "name": "合作方-GC图片",
                "img_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/icon\/gc.png",
                "is_jump": 1,
                "jump_url": "https:\/\/www.brabet.com\/license\/gc\/"
            },
            {
                "name": "合作方-SIQ图片",
                "img_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/icon\/siq.png",
                "is_jump": 0,
                "jump_url": ""
            }
        ]
    },
    "game_longgu_config": 0,
    "customer_service_switch": 0,
    "customer_service_entry_switch": 0,
    "is_debug": false,
    "current_sys_time": 1693797168,
    "new_user_task_system_switch": 0,
    "user_mobile_reg_switch": 1,
    "back_pic_icon": "",
    "picture_host": "https:\/\/d37kgoga0nrx6r.cloudfront.net",
    "pay_api_urls": [],
    "pay_channel_version": 1,
    "game_status": 1,
    "agent_share_reward_switch": 1,
    "ai_chat_robot_switch": 0,
    "chat_robot_entry_host": "",
    "chat_promote_entry_host": "",
    "ai_promote_robot_switch": "0",
    "ext_game_sport_show": 0,
    "lucky_wheel_activity_conf": {
        "start_time": 1680318000,
        "end_time": 1680490799
    },
    "wake_lock_enabled": 1,
    "whatsapp_show": {
        "status": 1,
        "whatsapp": "Online",
        "kf_chat_url": "https:\/\/home.brabet.com\/chat\/index"
    },
    "kf_show": {
        "status": 1,
        "kf_account": "13479195",
        "kf_type": "1",
        "kf_chat_url": "https:\/\/home.brabet.com\/chat\/index"
    },
    "kf_url": "https:\/\/home.brabet.com\/chat\/index",
    "is_stopgs": "0"
}