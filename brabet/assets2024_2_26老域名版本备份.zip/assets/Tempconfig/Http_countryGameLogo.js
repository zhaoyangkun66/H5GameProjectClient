module.exports = [
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/550.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/uploads\/game_icon_v10\/20230112\/edb196f741f098bc04311bb3a6bc335b.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/550.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/550.png",
        "gid": 550,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/uploads\/imgs\/20211223\/df81e9ab83ed20b836d04e956a960909.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/uploads\/game_icon_v10\/20230112\/3ebc0d7845e1cfb6613137a20711a4a7.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/470.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/470.png",
        "gid": 470,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/530.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/uploads\/game_icon_v10\/20230112\/953b7706909c6a92f7c91a4d36a347ac.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/530.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/uploads\/fury_pic_pc_url\/20221116\/610c3d912917fb7ea0b27777aa873132.png",
        "gid": 530,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/490.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/uploads\/game_icon_v10\/20230112\/69a2de172cbeb50450f4558c3c960496.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/490.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/490.png",
        "gid": 490,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/520.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/uploads\/game_icon_v10\/20230112\/a43aa1e2f43e894511b7726875fbdf6b.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/520.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/520.png",
        "gid": 520,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/840.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/uploads\/game_icon_v10\/20230210\/d93c6e2402688f339a5283174e54e784.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/840.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/840.png",
        "gid": 840,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/630.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/uploads\/game_icon_fury\/20221121\/4f99a8f1b4688dc30577d8d2dc7affb9.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/uploads\/fury_pic_phone_url\/20221118\/fb95c6bf929c07680663d446d6d2f95c.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/uploads\/fury_pic_pc_url\/20221118\/0e15fb032d0eed3bdcaed6969b2308a9.png",
        "gid": 630,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/600.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/uploads\/game_icon_v10\/20230112\/58faa8a307ba1aabd6f59d6f222425f7.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/600.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/600.png",
        "gid": 600,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/750.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/uploads\/game_icon_v10\/20230112\/aac8ec45938cbb8b5c035c9c7472ed5c.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/750.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/750.png",
        "gid": 750,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/220.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/220.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/220.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/220.png",
        "gid": 220,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/590.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/590.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/590.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/590.png",
        "gid": 590,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/400.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/400.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/400.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/400.png",
        "gid": 400,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/40.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/uploads\/game_icon_v10\/20230112\/fa7f773d15bec1e748909a04f4ab8da8.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/40.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/40.png",
        "gid": 40,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/uploads\/game_icon\/20221120\/432696000f70e8ee66eda615e85d5083.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/uploads\/game_icon_fury\/20221121\/6854b5f3d06ed71496ae1fe1aa587696.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/uploads\/fury_pic_phone_url\/20221120\/692f45ae620e9dd65da89fa95f1ff7e6.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/uploads\/fury_pic_pc_url\/20221120\/fccd524715d72af03c7e0944206df534.png",
        "gid": 760,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/60.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/60.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/60.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/60.png",
        "gid": 60,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/70.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/70.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/70.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/70.png",
        "gid": 70,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/171.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/171.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/171.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/171.png",
        "gid": 171,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/190.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/190.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/190.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/190.png",
        "gid": 190,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/210.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/210.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/210.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/210.png",
        "gid": 210,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/230.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/230.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/230.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/230.png",
        "gid": 230,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/240.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/240.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/240.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/240.png",
        "gid": 240,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/250.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/250.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/250.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/250.png",
        "gid": 250,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/260.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/260.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/260.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/260.png",
        "gid": 260,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/uploads\/imgs\/20211223\/036fd1b7c46a4a533900419708b7a066.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/uploads\/game_icon_v10\/20230425\/acf71db78f77070410554daebad31728.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/270.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/270.png",
        "gid": 270,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/290.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/290.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/290.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/290.png",
        "gid": 290,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/300.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/300.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/300.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/uploads\/fury_pic_pc_url\/20221118\/c8975c22cb3bebfd11d837bb7d425b7d.png",
        "gid": 300,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/310.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/310.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/310.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/310.png",
        "gid": 310,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/330.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/330.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/330.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/330.png",
        "gid": 330,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/340.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/340.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/340.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/340.png",
        "gid": 340,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/360.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/360.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/360.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/360.png",
        "gid": 360,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/370.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/370.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/370.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/370.png",
        "gid": 370,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/380.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/380.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/380.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/380.png",
        "gid": 380,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/390.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/390.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/390.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/390.png",
        "gid": 390,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/410.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/410.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/410.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/410.png",
        "gid": 410,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/450.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/450.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/450.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/450.png",
        "gid": 450,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/320.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/320.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/320.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/320.png",
        "gid": 320,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/uploads\/game_icon\/20220816\/55eae6c5caff39fc1c4ba4d3208f7b31.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/uploads\/game_icon\/20220816\/3282dc98f80de956f39a24538a1839dd.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/280.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/280.png",
        "gid": 280,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/650.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/uploads\/game_icon_fury\/20230102\/7b4cf310ce3c49c3f12686e60ff6a9cc.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/650.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/650.png",
        "gid": 650,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/430.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/430.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/430.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/430.png",
        "gid": 430,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/540.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/540.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/540.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/540.png",
        "gid": 540,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/560.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/560.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/560.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/560.png",
        "gid": 560,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/570.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/570.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/570.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/570.png",
        "gid": 570,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/580.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/580.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/580.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/580.png",
        "gid": 580,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/620.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/uploads\/game_icon_v10\/20230322\/742cca46a9db9e66c20634fab1a7d0d5.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/620.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/620.png",
        "gid": 620,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/680.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/680.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/680.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/680.png",
        "gid": 680,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/690.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/690.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/690.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/690.png",
        "gid": 690,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/700.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/uploads\/game_icon_v10\/20230210\/a386c1b200a6b2419fcd1f9cdb2b36c2.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/700.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/700.png",
        "gid": 700,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/710.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/710.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/710.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/710.png",
        "gid": 710,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/720.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/720.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/720.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/720.png",
        "gid": 720,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/730.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/uploads\/game_icon_v10\/20230210\/a674ef32b9164f9748e178ea8b0e46b2.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/730.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/730.png",
        "gid": 730,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/740.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/740.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/740.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/740.png",
        "gid": 740,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/770.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/uploads\/game_icon_fury\/20230102\/a4b43af901b7ba0b1183cfa2d1b327f7.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/770.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/770.png",
        "gid": 770,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/780.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/uploads\/game_icon_fury\/20230102\/fca9ab0355722a3b59c43dabf425ead0.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/780.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/780.png",
        "gid": 780,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/850.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/850.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/850.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/850.png",
        "gid": 850,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/880.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/880.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/880.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/880.png",
        "gid": 880,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/890.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/890.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/890.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/890.png",
        "gid": 890,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/900.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/900.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/900.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/900.png",
        "gid": 900,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/910.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/910.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/910.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/910.png",
        "gid": 910,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/1120.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/1120.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/1120.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/1120.png",
        "gid": 1120,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/1130.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/1130.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/1130.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/1130.png",
        "gid": 1130,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/1210.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/1210.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/1210.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/1210.png",
        "gid": 1210,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/480.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/480.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/480.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/480.png",
        "gid": 480,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/350.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/350.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/350.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/350.png",
        "gid": 350,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/420.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/420.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/420.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/420.png",
        "gid": 420,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/50.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/50.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/50.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/50.png",
        "gid": 50,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/30.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/uploads\/game_icon\/20221028\/9a6e1721f4baae00cf2088272b2bfbc9.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/30.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/30.png",
        "gid": 30,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/660.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/uploads\/game_icon_fury\/20221208\/f1672197a209458a322ad6e75f6bbdbc.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/660.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/660.png",
        "gid": 660,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/440.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/440.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/440.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/440.png",
        "gid": 440,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/500.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/500.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/500.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/500.png",
        "gid": 500,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/640.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/640.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/640.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/640.png",
        "gid": 640,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/670.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/670.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/670.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/670.png",
        "gid": 670,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/790.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/790.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/790.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/790.png",
        "gid": 790,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/800.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/800.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/800.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/800.png",
        "gid": 800,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/810.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/810.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/810.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/810.png",
        "gid": 810,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/820.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/820.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/820.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/820.png",
        "gid": 820,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/830.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/830.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/830.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/830.png",
        "gid": 830,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/860.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/860.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/860.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/860.png",
        "gid": 860,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/870.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/870.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/870.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/870.png",
        "gid": 870,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/920.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/920.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/920.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/920.png",
        "gid": 920,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/930.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/930.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/930.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/930.png",
        "gid": 930,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/940.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/940.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/940.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/940.png",
        "gid": 940,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/950.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/950.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/950.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/950.png",
        "gid": 950,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/970.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/970.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/970.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/970.png",
        "gid": 970,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/980.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/980.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/980.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/980.png",
        "gid": 980,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/990.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/990.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/990.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/990.png",
        "gid": 990,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/1000.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/1000.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/1000.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/1000.png",
        "gid": 1000,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/1010.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/uploads\/game_icon_v10\/20230517\/29179cd126a73f459903f1c239ba3eb4.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/1010.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/1010.png",
        "gid": 1010,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/1020.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/1020.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/1020.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/1020.png",
        "gid": 1020,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/1030.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/1030.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/1030.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/1030.png",
        "gid": 1030,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/1040.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/1040.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/1040.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/1040.png",
        "gid": 1040,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/1050.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/1050.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/1050.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/1050.png",
        "gid": 1050,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/1060.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/1060.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/1060.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/1060.png",
        "gid": 1060,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/1070.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/1070.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/1070.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/1070.png",
        "gid": 1070,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/1080.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/1080.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/1080.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/1080.png",
        "gid": 1080,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/1100.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/1100.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/1100.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/1100.png",
        "gid": 1100,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/1110.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/1110.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/1110.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/1110.png",
        "gid": 1110,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/1140.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/1140.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/1140.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/1140.png",
        "gid": 1140,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/1190.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/1190.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/1190.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/1190.png",
        "gid": 1190,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/1200.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/1200.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/1200.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/1200.png",
        "gid": 1200,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/1220.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/1220.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/1220.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/1220.png",
        "gid": 1220,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/1230.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/1230.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/1230.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/1230.png",
        "gid": 1230,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/1240.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/1240.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/1240.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/1240.png",
        "gid": 1240,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/1241.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/1241.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/1241.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/1241.png",
        "gid": 1241,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/1290.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/1290.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/1290.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/1290.png",
        "gid": 1290,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/1300.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/1300.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/1300.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/1300.png",
        "gid": 1300,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/1320.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/1320.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/1320.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/1320.png",
        "gid": 1320,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/1330.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/1330.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/1330.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/1330.png",
        "gid": 1330,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/1340.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/1340.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/1340.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/1340.png",
        "gid": 1340,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/1350.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/1350.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/1350.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/1350.png",
        "gid": 1350,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/1360.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/1360.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/1360.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/1360.png",
        "gid": 1360,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    },
    {
        "pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/1370.png",
        "fury_pic_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/game_icon\/v10\/1370.png",
        "fury_pic_phone_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_phone_url\/1370.png",
        "fury_pic_pc_url": "https:\/\/d37kgoga0nrx6r.cloudfront.net\/static\/images\/fury_pic_pc_url\/1370.png",
        "gid": 1370,
        "style": 1,
        "language": "en-us",
        "language_id": 2
    }
]
