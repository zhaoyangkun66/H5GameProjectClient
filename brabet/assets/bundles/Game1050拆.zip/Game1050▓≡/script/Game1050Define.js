let i={} 
Object.defineProperty(i, "__esModule", {
    value: true
}),
i.Game1050AddNum = i.Game1050UIName = i.Game1050TipsType = i.Game1050HistoryList = i.Game1050HistoryDataItem = i.enum_Game1050Status = i.Recv_1050BetItem = i.Recv_PropsList = i.Recv_PropsListWin_arrs = i.Req_1050BetItem = i.Game1050BetDefault = i.TipsType = i.Game1050BtnPlayName = i.Game1050BigWinName = i.Game1050DragonBonesName = i.GameProp = i.Game1050HttpAPI = void 0;
var n = function() {
    function t() {}
    return t.GameDates = "/single_game.Panada/initRoom",
    t.BetResult = "/single_game.Panada/gameResult",
    t.BetHistory = "/goldgame/panada_user_gold_history",
    t.BetOneDayHistory = "/goldgame/panada_user_history",
    t
}();
i.Game1050HttpAPI = n,
function(t) {
    t[t.NullBox = 0] = "NullBox",
    t[t.Bamboo = 1] = "Bamboo",
    t[t.Peach = 2] = "Peach",
    t[t.PurpleDiamonds = 3] = "PurpleDiamonds",
    t[t.Weapon = 4] = "Weapon",
    t[t.LuckyBag = 5] = "LuckyBag",
    t[t.Yupei = 6] = "Yupei",
    t[t.Omnipotence = 7] = "Omnipotence"
}(i.GameProp || (i.GameProp = {})),
function(t) {
    t.Normal = "idle",
    t.Normal2 = "idle2",
    t.Normal3 = "idle3",
    t.za = "idle4",
    t.nod = "win",
    t.win_nod = "win2",
    t.anger = "idle5",
    t.excited = "",
    t.stare = "zo_start",
    t.stare_loop = "zo_idle",
    t.stare_happy = "rs_start",
    t.happy = "rs_idle",
    t.happy_win_show = "rs_win",
    t.happy_win_loop = "rs_win_idle",
    t.happy_win_end = "rs_win_exit",
    t.normal_show = "wild_collect"
}(i.Game1050DragonBonesName || (i.Game1050DragonBonesName = {})),
function(t) {
    t.bigwin_act = "bw_spawn",
    t.bigwin_loop = "bw_idle",
    t.megawin_act = "mw_spawn",
    t.megawin_loop = "mw_idle",
    t.supermegawin_act = "smw_spawn",
    t.supermegawin_loop = "smw_idle"
}(i.Game1050BigWinName || (i.Game1050BigWinName = {})),
function(t) {
    t.Normal = "btn_start_normal",
    t.Press = "btn_start_Press",
    t.auto = "btn_start_auto",
    t.startClick = "btn_start_click"
}(i.Game1050BtnPlayName || (i.Game1050BtnPlayName = {})),
function(t) {
    t[t.randomTip1 = 0] = "randomTip1",
    t[t.randomTip2 = 1] = "randomTip2",
    t[t.randomTip3 = 2] = "randomTip3",
    t[t.randomTip4 = 3] = "randomTip4",
    t[t.luckTips = 4] = "luckTips",
    t[t.goldTips = 5] = "goldTips"
}(i.TipsType || (i.TipsType = {}));
i.Game1050BetDefault = function() {}
;
i.Req_1050BetItem = function() {}
;
i.Recv_PropsListWin_arrs = function() {}
;
i.Recv_PropsList = function() {}
;
i.Recv_1050BetItem = function() {}
,
function(t) {
    t[t.INIT = 0] = "INIT",
    t[t.GAMERESULT = 1] = "GAMERESULT",
    t[t.GAME_END = 2] = "GAME_END",
    t[t.GAME_ENDED = 3] = "GAME_ENDED"
}(i.enum_Game1050Status || (i.enum_Game1050Status = {}));
i.Game1050HistoryDataItem = function() {}
;
var o = function(t) {
    function e() {
        return null !== t && t.apply(this, arguments) || this
    }
    return __extends(e, t),
    e
}(Array);
i.Game1050HistoryList = o,
function(t) {
    t[t.MinimumBet = 0] = "MinimumBet",
    t[t.MaximumBet = 1] = "MaximumBet",
    t[t.TURBO_ON = 2] = "TURBO_ON",
    t[t.TURBO_OFF = 3] = "TURBO_OFF"
}(i.Game1050TipsType || (i.Game1050TipsType = {}));
var a = function() {
    function t() {}
    return t.UIGame1050Help = "Game1050Help",
    t.UIGame1050BetCommon = "UIGame1050BetCommon",
    t.UIGame1050Record = "UIGame1050Record",
    t.UIGame1050Daily = "UIGame1050Daily",
    t.UIGame1050BetDetails = "UIGame1050BetDetails",
    t.Game_1050Help = "Game_1050Help",
    t.UIGame1050BigWin = "UIGame1050BigWin",
    t.UIGame1050Tips = "UIGame1050Tips",
    t
}();
i.Game1050UIName = a,
i.Game1050AddNum = [1.11, 11.11, 111, 1111, 11111],
module.exports = i
