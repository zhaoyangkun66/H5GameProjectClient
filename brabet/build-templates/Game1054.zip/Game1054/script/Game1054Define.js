let i = {}
Object.defineProperty(i, "__esModule", {
    value: true
}),
    i.Game1054AddNum = i.Game1054UIName = i.Game1054TipsType = i.Game1054HistoryList = i.Game1054HistoryDataItem = i.enum_Game1054Status = i.Recv_1054BetItem = i.Recv_PropsList = i.Recv_PropsListWin_arrs = i.Req_1054BetItem = i.Game1054BetDefault = i.TipsType = i.Game1054BtnPlayName = i.Game1054BigWinName = i.Game1054DragonBonesName = i.GameProp = i.Game1054HttpAPI = void 0;
var n = function () {
    function t() { }
    return t.GameDates = "/single_game.OX/initRoom",//OX
        t.BetResult = "/single_game.OX/gameResult",
        // t.BetHistory = "/goldgame/Dragon_user_gold_history",
        t.BetOneDayHistory = "/goldgame/OX_user_history",
        t
}();
i.Game1054HttpAPI = n,
    function (t) {
        t[t.NullBox = 0] = "NullBox",
            t[t.Bamboo = 1] = "Bamboo",
            t[t.Peach = 2] = "Peach",
            t[t.PurpleDiamonds = 3] = "PurpleDiamonds",
            t[t.Weapon = 4] = "Weapon",
            t[t.LuckyBag = 5] = "LuckyBag",
            t[t.Yupei = 6] = "Yupei",
            t[t.Omnipotence = 7] = "Omnipotence"
    }(i.GameProp || (i.GameProp = {})),
    function (t) {
        t.Normal = "idle",
            t.Normal2 = "idle2",
            t.Normal3 = "",
            t.za = "",
            t.nod = "wild_collect",
            t.win_nod = "win",
            t.anger = "rs_exit",
            //t.excited = "",
            t.stare = "rs_start",
            t.stare_loop = "rs_idle",
            t.dup = "dup",
            // t.happy = "tease_win_idle",
            t.happy_win_show = "rs_win",
            t.happy_win_loop = "rsg_win_idle",
            t.happy_win_end = "rsg_win_exit",
            t.normal_show = "win2"
    }(i.Game1054DragonBonesName || (i.Game1054DragonBonesName = {})),
    function (t) {
        t.bigwin_act = "big",
            t.bigwin_loop = "",
            t.megawin_act = "mege",
            t.megawin_loop = "mege_stop",
            t.supermegawin_act = "super",
            t.supermegawin_loop = "super_stop"
    }(i.Game1054BigWinName || (i.Game1054BigWinName = {})),
    function (t) {
        t.bigwin_act = "bw_spawn",
            t.bigwin_loop = "bw_idle",
            t.megawin_act = "mw_spawn",
            t.megawin_loop = "mw_idle",
            t.supermegawin_act = "smw_spawn",
            t.supermegawin_loop = "smw_idle"
    }(i.Game1054BigWinName2 || (i.Game1054BigWinName2 = {})),
    function (t) {
        t.Normal = "btn_start_normal",
            t.Press = "btn_start_Press",
            t.auto = "btn_start_auto",
            t.startClick = "btn_start_click"
    }(i.Game1054BtnPlayName || (i.Game1054BtnPlayName = {})),
    function (t) {
        t[t.randomTip1 = 0] = "randomTip1",
            t[t.randomTip2 = 1] = "randomTip2",
            t[t.randomTip3 = 2] = "randomTip3",
            t[t.randomTip4 = 3] = "randomTip4",
            t[t.randomTip5 = 4] = "randomTip5",
            t[t.goldTips = 5] = "goldTips"
    }(i.TipsType || (i.TipsType = {}));
i.Game1054BetDefault = function () { }
    ;
i.Req_1054BetItem = function () { }
    ;
i.Recv_PropsListWin_arrs = function () { }
    ;
i.Recv_PropsList = function () { }
    ;
i.Recv_1054BetItem = function () { }
    ,
    function (t) {
        t[t.INIT = 0] = "INIT",
            t[t.GAMERESULT = 1] = "GAMERESULT",
            t[t.GAME_END = 2] = "GAME_END",
            t[t.GAME_ENDED = 3] = "GAME_ENDED"
    }(i.enum_Game1054Status || (i.enum_Game1054Status = {}));
i.Game1054HistoryDataItem = function () { }
    ;
var o = function (t) {
    function e() {
        return null !== t && t.apply(this, arguments) || this
    }
    return __extends(e, t),
        e
}(Array);
i.Game1054HistoryList = o,
    function (t) {
        t[t.MinimumBet = 0] = "MinimumBet",
            t[t.MaximumBet = 1] = "MaximumBet",
            t[t.TURBO_ON = 2] = "TURBO_ON",
            t[t.TURBO_OFF = 3] = "TURBO_OFF"
    }(i.Game1054TipsType || (i.Game1054TipsType = {}));
var a = function () {
    function t() { }
    return t.UIGame1054Help = "Game1054Help",
        t.UIGame1054BetCommon = "UIGame1054BetCommon",
        t.UIGame1054SelectDateRange = "UIGame1054SelectDateRange",
        t.UIGame1054Daily = "UIGame1054Daily",
        t.UIGame1054BetDetails = "UIGame1054BetDetails",
        t.Game_1054Help = "Game_1054Help",
        t.Game_1054Rules = "Game_1054Rules",
        t.UIGame1054BigWin = "UIGame1054BigWin",
        t.UIGame1054BigWinLuck = "UIGame1054BigWinLuck",
        t.UIGame1054Tips = "UIGame1054Tips",
        t
}();
i.Game1054UIName = a,
    i.Game1054AddNum = [1.11, 11.11, 111, 1111, 11111],
    module.exports = i
